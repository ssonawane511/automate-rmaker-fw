
#include "app_includes.h"
static const char *TAG = "app_main";

esp_err_t err;

esp_rmaker_node_t *x1;

esp_rmaker_device_t *lightbulb_device;
esp_rmaker_device_t *fan_device;

static void initialize_rainmaker_node()
{
    esp_rmaker_config_t rainmaker_cfg = {
        .enable_time_sync = false,
    };
    x1 = esp_rmaker_node_init(
        &(esp_rmaker_config_t){
            .enable_time_sync = true,
        },
        "X1", "esp.X1");
    if (!x1)
    {
        ESP_LOGE(TAG, "Failed to initialize RainMaker Node");
        abort();
    }
}

/*!
 *  @brief Sets up a lightbulb device and adds it to the node.
 *  @param node A pointer to the ESP RainMaker node to which the lightbulb will be added.
 */
static void setup_lightbulb_device()
{
    lightbulb_device = esp_rmaker_lightbulb_device_create("Lightbulb", NULL, false);

    esp_rmaker_param_t *brightness_param = esp_rmaker_brightness_param_create(ESP_RMAKER_DEF_BRIGHTNESS_NAME, 0);
    esp_rmaker_param_t *hue_param = esp_rmaker_hue_param_create(ESP_RMAKER_DEF_HUE_NAME, 0);
    esp_rmaker_param_t *saturation_param = esp_rmaker_saturation_param_create(ESP_RMAKER_DEF_SATURATION_NAME, 0);

    esp_rmaker_device_add_param(lightbulb_device, brightness_param);
    esp_rmaker_device_add_param(lightbulb_device, hue_param);
    esp_rmaker_device_add_param(lightbulb_device, saturation_param);

    esp_rmaker_node_add_device(x1, lightbulb_device);
    esp_rmaker_device_add_cb(lightbulb_device, lightbulb_write_cb, NULL);
}

/*!
 *  @brief Sets up a fan device and adds it to the node.
 *  @param node A pointer to the ESP RainMaker node to which the fan will be added.
 */
static void setup_fan_device()
{
    fan_device = esp_rmaker_fan_device_create("Fan", NULL, false);

    esp_rmaker_param_t *speed_param = esp_rmaker_speed_param_create(ESP_RMAKER_DEF_SPEED_NAME, 0);

    esp_rmaker_device_add_param(fan_device, speed_param);

    esp_rmaker_node_add_device(x1, fan_device);
    esp_rmaker_device_add_cb(fan_device, fan_write_cb, NULL);
}

static void init_nvs(void)
{
    err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(err);
}
/*! @brief Start the Wi-Fi.
 *  @note  If the node is provisioned, it will start connection attempts,
 *         else, it will start Wi-Fi provisioning. The function will return
 *         after a connection has been successfully established. This is when the qrcode is display.
 */
static void start_wifi(void)
{
    err = app_network_start(POP_TYPE_RANDOM);

    if (err != ESP_OK)
    {
        ESP_LOGE(TAG, "Could not start Wifi. Aborting!!!");
        vTaskDelay(5000 / portTICK_PERIOD_MS);
        abort();
    }
}

void app_main()
{
    esp_rmaker_console_init();
    init_nvs();
    app_network_init();
    initialize_rainmaker_node();

    setup_lightbulb_device();
    setup_fan_device();

    if (esp_rmaker_timezone_service_enable() == ESP_OK)
    {
        ESP_LOGI("Time Service", "Time Service enabled successfully.");
    }
    else
    {
        ESP_LOGE("Time Service", "Failed to enable Time Service.");
    }

    if (esp_rmaker_ota_enable_default() == ESP_OK)
    {
        ESP_LOGI("OTA Service", "OTA Service enabled successfully.");
    }
    else
    {
        ESP_LOGE("OTA Service", "Failed to enable OTA Service.");
    }

    if (esp_rmaker_scenes_enable() == ESP_OK)
    {
        ESP_LOGI("Scenes Service", "Scenes Service enabled successfully.");
    }
    else
    {
        ESP_LOGE("Scenes Service", "Failed to enable Scenes Service.");
    }

    if (esp_rmaker_schedule_enable() == ESP_OK)
    {
        ESP_LOGI("Schedule Service", "Schedule Service enabled successfully.");
    }
    else
    {
        ESP_LOGE("Schedule Service", "Failed to enable Schedule Service.");
    }

    esp_rmaker_start();
    start_wifi();
}
