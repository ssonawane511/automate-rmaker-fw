
#include "app_includes.h"
static const char *TAG = "app_main";

esp_err_t err;

esp_rmaker_node_t *fff;

esp_rmaker_device_t *lightbulb_0_device;

static void initialize_rainmaker_node()
{
    esp_rmaker_config_t rainmaker_cfg = {
        .enable_time_sync = false,
    };
    fff = esp_rmaker_node_init(
        &(esp_rmaker_config_t){
            .enable_time_sync = true,
        },
        "fff", "");
    if (!fff)
    {
        ESP_LOGE(TAG, "Failed to initialize RainMaker Node");
        abort();
    }
}

/*!
 *  @brief Sets up a lightbulb device and adds it to the node.
 *  @param node A pointer to the ESP RainMaker node to which the lightbulb will be added.
 */
static void setup_lightbulb_0_device()
{
    lightbulb_0_device = esp_rmaker_lightbulb_device_create("Light bulb", NULL, true);

    esp_rmaker_node_add_device(fff, lightbulb_0_device);
    esp_rmaker_device_add_cb(lightbulb_0_device, lightbulb_0_write_cb, NULL);
}

static void init_nvs(void)
{
    err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(err);
}
/*! @brief Start the Wi-Fi.
 *  @note  If the node is provisioned, it will start connection attempts,
 *         else, it will start Wi-Fi provisioning. The function will return
 *         after a connection has been successfully established. This is when the qrcode is display.
 */
static void start_wifi(void)
{
    err = app_network_start(POP_TYPE_RANDOM);

    if (err != ESP_OK)
    {
        ESP_LOGE(TAG, "Could not start Wifi. Aborting!!!");
        vTaskDelay(5000 / portTICK_PERIOD_MS);
        abort();
    }
}

void app_main()
{
    esp_rmaker_console_init();
    init_nvs();
    app_network_init();
    initialize_rainmaker_node();

    setup_lightbulb_0_device();

    if (esp_rmaker_timezone_service_enable() == ESP_OK)
    {
        ESP_LOGI("Time Service", "Time Service enabled successfully.");
    }
    else
    {
        ESP_LOGE("Time Service", "Failed to enable Time Service.");
    }

    if (esp_rmaker_schedule_enable() == ESP_OK)
    {
        ESP_LOGI("Schedule Service", "Schedule Service enabled successfully.");
    }
    else
    {
        ESP_LOGE("Schedule Service", "Failed to enable Schedule Service.");
    }

    esp_rmaker_start();
    start_wifi();
}
