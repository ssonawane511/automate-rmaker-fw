#ifndef DRIVER_H
#define DRIVER_H

#include "app_includes.h"

void lightbulb_driver_set_power(bool value);
void lightbulb_driver_set_brightness(int value);
void lightbulb_driver_set_hue(int value);
void lightbulb_driver_set_saturation(int value);
void fan_driver_set_power(bool value);
void fan_driver_set_speed(int value);

#endif  // DRIVER_H
