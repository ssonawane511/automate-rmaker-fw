#include "app_driver.h"

#include "app_includes.h"

void lightbulb_driver_set_power(bool value)
{
    // TODO: Implement driver logic for setting power
    ESP_LOGI("lightbulb Driver", "Setting power to value.");
}

void lightbulb_driver_set_brightness(int value)
{
    // TODO: Implement driver logic for setting brightness
    ESP_LOGI("lightbulb Driver", "Setting brightness to value.");
}

void lightbulb_driver_set_hue(int value)
{
    // TODO: Implement driver logic for setting hue
    ESP_LOGI("lightbulb Driver", "Setting hue to value.");
}

void lightbulb_driver_set_saturation(int value)
{
    // TODO: Implement driver logic for setting saturation
    ESP_LOGI("lightbulb Driver", "Setting saturation to value.");
}

void fan_driver_set_power(bool value)
{
    // TODO: Implement driver logic for setting power
    ESP_LOGI("fan Driver", "Setting power to value.");
}

void fan_driver_set_speed(int value)
{
    // TODO: Implement driver logic for setting speed
    ESP_LOGI("fan Driver", "Setting speed to value.");
}
