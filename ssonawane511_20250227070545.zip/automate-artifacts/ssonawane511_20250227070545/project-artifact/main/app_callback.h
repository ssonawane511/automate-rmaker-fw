#ifndef DEVICE_CALLBACKS_H
#define DEVICE_CALLBACKS_H

#include "app_includes.h"

esp_err_t temp_sensor_write_cb(const esp_rmaker_device_t *device, const esp_rmaker_param_t *param, const esp_rmaker_param_val_t val, void *priv_data,
                               esp_rmaker_write_ctx_t *ctx);
esp_err_t switch_write_cb(const esp_rmaker_device_t *device, const esp_rmaker_param_t *param, const esp_rmaker_param_val_t val, void *priv_data,
                          esp_rmaker_write_ctx_t *ctx);

#endif  // DEVICE_CALLBACKS_H
