#include "app_driver.h"

#include "app_includes.h"

void switch_driver_set_power(bool value)
{
    // TODO: Implement driver logic for setting power
    ESP_LOGI("switch Driver", "Setting power to value.");
}

void lightbulb_driver_set_hue(int value)
{
    // TODO: Implement driver logic for setting hue
    ESP_LOGI("lightbulb Driver", "Setting hue to value.");
}
