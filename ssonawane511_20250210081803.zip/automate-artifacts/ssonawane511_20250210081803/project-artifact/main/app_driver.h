#ifndef DRIVER_H
#define DRIVER_H

#include "app_includes.h"

void switch_driver_set_power(bool value);
void lightbulb_driver_set_hue(int value);

#endif  // DRIVER_H
