#include "app_driver.h"

#include "app_includes.h"

void lightbulb_0_driver_set_name(const char* value)
{
    // TODO: Implement driver logic for setting Name
    ESP_LOGI("lightbulb Driver", "Setting Name to value.");
}

void lightbulb_0_driver_set_power(bool value)
{
    // TODO: Implement driver logic for setting Power
    ESP_LOGI("lightbulb Driver", "Setting Power to value.");
}

void temp_sensor_1_driver_set_name(const char* value)
{
    // TODO: Implement driver logic for setting Name
    ESP_LOGI("temp_sensor Driver", "Setting Name to value.");
}

void temp_sensor_1_driver_set_temperature(float value)
{
    // TODO: Implement driver logic for setting Temperature
    ESP_LOGI("temp_sensor Driver", "Setting Temperature to value.");
}

void fan_2_driver_set_name(const char* value)
{
    // TODO: Implement driver logic for setting Name
    ESP_LOGI("fan Driver", "Setting Name to value.");
}

void fan_2_driver_set_power(bool value)
{
    // TODO: Implement driver logic for setting Power
    ESP_LOGI("fan Driver", "Setting Power to value.");
}
