#ifndef DRIVER_H
#define DRIVER_H

#include "app_includes.h"

void lightbulb_0_driver_set_name(const char* value);
void lightbulb_0_driver_set_power(bool value);
void temp_sensor_1_driver_set_name(const char* value);
void temp_sensor_1_driver_set_temperature(float value);
void fan_2_driver_set_name(const char* value);
void fan_2_driver_set_power(bool value);

#endif  // DRIVER_H
